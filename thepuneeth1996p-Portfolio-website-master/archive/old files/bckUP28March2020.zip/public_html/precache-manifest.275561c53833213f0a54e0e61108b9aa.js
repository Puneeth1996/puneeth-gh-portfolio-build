self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6a26a32329ac5d76dbec777c551d53e5",
    "url": "/index.html"
  },
  {
    "revision": "8f337fc774bcbd318bd4",
    "url": "/static/css/2.67123b20.chunk.css"
  },
  {
    "revision": "8706bd6d719ace636253",
    "url": "/static/css/main.a1b7b015.chunk.css"
  },
  {
    "revision": "8f337fc774bcbd318bd4",
    "url": "/static/js/2.d496fc85.chunk.js"
  },
  {
    "revision": "8706bd6d719ace636253",
    "url": "/static/js/main.7de0c69d.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "1ae8ff90c99b507edd2b27716cbfa7e4",
    "url": "/static/media/city-tours-planner.1ae8ff90.png"
  },
  {
    "revision": "954e00db47085a56e4dacc554e1b28ed",
    "url": "/static/media/contactme.954e00db.jpg"
  },
  {
    "revision": "c72f5b313c25ceee213db6442346f2a7",
    "url": "/static/media/dronemakers.c72f5b31.png"
  },
  {
    "revision": "d6abe8862131a68e525b6805b2d431ef",
    "url": "/static/media/eporiumusa.d6abe886.png"
  },
  {
    "revision": "4495f110e51e9a586e1ff06f519d8389",
    "url": "/static/media/guestList.4495f110.png"
  },
  {
    "revision": "14cd50e35a8125170ce7ceb8cb41818f",
    "url": "/static/media/mealPlanner.14cd50e3.png"
  },
  {
    "revision": "97e5a8ec37e384a7b78dc2f06916ad0e",
    "url": "/static/media/mini-chat-app.97e5a8ec.png"
  },
  {
    "revision": "4cdd7091b4db66ce2c0cdd6d6c61e687",
    "url": "/static/media/myimg.4cdd7091.jpg"
  },
  {
    "revision": "29e05b5891791143b5f7bb24d5d92d61",
    "url": "/static/media/projects.29e05b58.jpg"
  },
  {
    "revision": "b31ef431dea665cc3914f08f3c33aed0",
    "url": "/static/media/reactWeatherApp.b31ef431.png"
  },
  {
    "revision": "24d1357b192a8c8051fd0cd7a656c190",
    "url": "/static/media/techStoreEcom.24d1357b.png"
  }
]);